<script src="{{asset('dist/js/jquery-2.2.3.js')}}" type="text/javascript"></script>
<script src="{{asset('dist/js/bootstrap.min.js')}}" type="text/javascript"></script>
<script src="{{asset('dist/js/jquery.themepunch.tools.min.js')}}"></script>
<script src="{{asset('dist/js/jquery.themepunch.revolution.min.js')}}"></script>
<script src="{{asset('dist/js/revolution.extension.layeranimation.min.js')}}"></script>
<script src="{{asset('dist/js/revolution.extension.navigation.min.js')}}"></script>
<script src="{{asset('dist/js/revolution.extension.parallax.min.js')}}"></script>
<script src="{{asset('dist/js/revolution.extension.slideanims.min.js')}}"></script>
<script src="{{asset('dist/js/revolution.extension.video.min.js')}}"></script>
<script src="{{asset('dist/js/slider.js')}}" type="text/javascript"></script>
<script src="{{asset('dist/js/owl.carousel.min.js')}}" type="text/javascript"></script>
<script src="{{asset('dist/js/jquery.parallax-1.1.3.js')}}"></script>
<script src="{{asset('dist/js/jquery.mixitup.min.js')}}"></script>
<script src="{{asset('dist/js/jquery-countTo.js')}}"></script>
<script src="{{asset('dist/js/jquery.appear.js')}}"></script>
<script src="{{asset('dist/js/jquery.fancybox.js')}}"></script>
<script src="{{asset('dist/js/functions.js')}}" type="text/javascript"></script>