<section class="info_section paralax">
    <div class="container">
        <div class="row">
            <div class="col-md-2"> </div>
            <div class="col-md-8">
                <div class="text-center">
                    <h2 class="heading_space">HOT Deal of the Day</h2>
                    <p class="heading_space detail">Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore nulla facilisis. velit esse molestie consequat, vel illum dolore nulla facilisis.</p>
                    <a href="#order-form" class="btn-common-white page-scroll">Order Now</a>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
</section>