<!-- facts counter  -->
<section id="facts">
    <div class="container">
        <div class="row number-counters">
            <!-- first count item -->
            <div class="col-sm-3 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="300ms">
                <div class="counters-item row">
                    <i class="icon-smile"></i>
                    <h2><strong data-to="4680">0</strong></h2>
                    <p>Happy Customers</p>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="600ms">
                <div class="counters-item  row">
                    <i class="icon-food"></i>
                    <h2><strong data-to="865">0</strong></h2>
                    <p>Dishes Served</p>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="900ms">
                <div class="counters-item  row">
                    <i class="icon-glass"></i>
                    <h2><strong data-to="510">0</strong></h2>
                    <p>Total Beverages</p>
                </div>
            </div>
            <div class="col-sm-3 col-xs-12 text-center wow fadeInDown" data-wow-duration="500ms" data-wow-delay="1200ms">
                <div class="counters-item  row">
                    <i class="icon-coffee"></i>
                    <h2><strong data-to="1350">0</strong></h2>
                    <p>Cup of coffees</p>
                </div>
            </div>
        </div>
    </div>
</section>
