
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/bootstrap.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/font-awesome.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/bistro-icons.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/animate.min.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/settings.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/navigation.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/owl.carousel.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/owl.transitions.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/jquery.fancybox.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/zerogrid.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/style.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('dist/css/loader.css')}}">
    <link rel="shortcut icon" href="{{asset('dist/images/favicon.png')}}">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
