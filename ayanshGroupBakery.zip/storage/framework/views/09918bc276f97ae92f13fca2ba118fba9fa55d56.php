<div class="loader">
    <div class="cssload-container">
        <div class="cssload-circle"></div>
        <div class="cssload-circle"></div>
    </div>
</div><?php /**PATH E:\Development\Web-Development\xampp\htdocs\ayanshGroupBakery\resources\views/live/includes/loader.blade.php ENDPATH**/ ?>