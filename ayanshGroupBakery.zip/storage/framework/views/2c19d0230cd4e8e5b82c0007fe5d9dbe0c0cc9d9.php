
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/bistro-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/animate.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/settings.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/navigation.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/owl.transitions.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/jquery.fancybox.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/zerogrid.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/style.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dist/css/loader.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('dist/images/favicon.png')); ?>">

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<?php /**PATH E:\Development\Web-Development\xampp\htdocs\ayanshGroupBakery\resources\views/live/includes/top_scripts.blade.php ENDPATH**/ ?>