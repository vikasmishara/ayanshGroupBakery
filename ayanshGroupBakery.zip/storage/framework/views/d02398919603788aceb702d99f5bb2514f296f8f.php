<div class="topbar">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p class="pull-left hidden-xs">Ayansh Group, the Best in Town</p>
                <p class="pull-right"><i class="fa fa-phone"></i>Order Online 111-123-6789</p>
            </div>
        </div>
    </div>
</div><?php /**PATH E:\Development\Web-Development\xampp\htdocs\ayanshGroupBakery\resources\views/live/includes/top_bar.blade.php ENDPATH**/ ?>