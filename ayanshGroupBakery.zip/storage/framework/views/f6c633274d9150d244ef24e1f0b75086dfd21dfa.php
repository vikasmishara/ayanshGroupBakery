<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ayansh Group | Gallery</title>
    <?php echo $__env->make('live.includes.top_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

<!--Topbar-->
<?php echo $__env->make('live.includes.top_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!--Header-->
<?php echo $__env->make('live.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--Page header & Title-->
<section id="page_header">
    <div class="page_title">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="title">Gallery</h2>
                </div>
            </div>
        </div>
    </div>
</section>


<section id="gallery" class="padding-top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="work-filter">
                    <ul class="text-center">
                        <li><a href="javascript:;" data-filter=".drinks" class="filter">All drinks </a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="zerogrid">
                <div class="wrap-container">
                    <div class="wrap-content clearfix">
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-1-3 mix work-item drinks heading_space">
                            <div class="wrap-col">
                                <div class="item-container">
                                    <div class="image">
                                        <img src="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" alt="cook"/>
                                        <div class="overlay">
                                            <a class="fancybox overlay-inner" href="<?php echo e(asset('dist/images/gallery1.jpg')); ?>" data-fancybox-group="gallery"><i class=" icon-eye6"></i></a>
                                        </div>
                                    </div>
                                    <div class="gallery_content">
                                        <h3>Herbs & Cheese Stake</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!--Footer-->
<?php echo $__env->make('live.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<a href="#" id="back-top"><i class="fa fa-angle-up fa-2x"></i></a>

<?php echo $__env->make('live.includes.bottom_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH E:\Development\Web-Development\xampp\htdocs\ayanshGroupBakery\resources\views/live/pages/gallery.blade.php ENDPATH**/ ?>